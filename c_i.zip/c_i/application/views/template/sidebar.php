<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="profile.html"><img src="<?php echo base_url(); ?>assets/img/ui-sam.jpg" class="img-circle" width="60"></a></p>
              	  <h5 class="centered">M Fikrul Bachtiar</h5>
              	  	
                  <li class="mt">
                      <a href="<?php base_url() ?>home">
                          <i class="fa fa-home"></i>
                          <span>HOME</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="<?php base_url() ?>produk">
                            <i class="fa fa-desktop"></i>
                            <span>Produk</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-cogs"></i>
                          <span>Kategori</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="calendar.html">Lemari Anak</a></li>
                          <li><a  href="gallery.html">Lemari Dapur</a></li>
                          <li><a  href="todo_list.html">Lemari Hias</a></li>
                          <li><a  href="todo_list.html">Lemari Pakaian</a></li>
                          <li><a  href="todo_list.html">Lemari TV</a></li>
                          <li><a  href="todo_list.html">Meja Belajar</a></li>
                          <li><a  href="todo_list.html">Rak Sepatu</a></li>
                          <li><a  href="todo_list.html">Rak Susun Plastik</a></li>
                          <li><a  href="todo_list.html">Tempat Tidur Bayi</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-book"></i>
                          <span>Tentang Kami</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-tasks"></i>
                          <span>Keranjang</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-th"></i>
                          <span>Cara Belanja</span>
                      </a>
                  </li>
              </ul>
          </div>
      </aside>