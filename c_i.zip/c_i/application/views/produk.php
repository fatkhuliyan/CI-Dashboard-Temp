<!--main content start-->
<section id="main-content">
  <section class="wrapper">
    <div class="row">
        <div class="col-lg-9 main-chart">
          <div class="row mt">

           
    	<div class="col-md-4 col-sm-4 mb">
    	    <div class="white-panel pn">
        	  	<div class="white-header">
            	 <h5>PLASMA 6</h5>
            	</div>
          		<div class="row">
            		<div class="col-sm-6 col-xs-6 goleft">
              			<p><i class="fa fa-dollar"></i> 532.000</p>
            		</div>
            		<div class="col-sm-6 col-xs-6"></div>
          		</div>
          		<div class="centered">
            		<img src="<?php echo base_url(); ?>assets/img/H0007.JPG" width="200">
          		</div>
        	</div>
    	</div><!-- /col-md-4-->
    	
    	<div class="col-md-4 col-sm-4 mb">
    		<div class="white-panel pn">
    			<div class="white-header">
			           <h5>PLASMA 99</h5>
    			</div>
	            <div class="row">
            		<div class="col-sm-6 col-xs-6 goleft">
              			<p><i class="fa fa-dollar"></i> 752.000</p>
            		</div>
            		<div class="col-sm-6 col-xs-6"></div>
      			</div>
      			<div class="centered">
            		<img src="<?php echo base_url(); ?>assets/img/H0008.JPG" width="200">
      			</div>
    		</div>
    	</div><!-- /col-md-4 -->
    	
		<div class="col-md-4 col-sm-4 mb">
        	<div class="white-panel pn">
          		<div class="white-header">
             		<h5>RAK SEPATU 120</h5>
          		</div>
          		<div class="row">
            		<div class="col-sm-6 col-xs-6 goleft">
              			<p><i class="fa fa-dollar"></i> 450.000</p>
            		</div>
            		<div class="col-sm-6 col-xs-6"></div>
          		</div>
          		<div class="centered">
            		<img src="<?php echo base_url(); ?>assets/img/H0006.JPG" width="120">
          		</div>
        	</div>
     	</div><!-- /col-md-4 -->
    </div><!-- /row -->
   
   	<div class="row">
		<div class="col-md-4 mb">
            <div class="white-panel pn">
                <div class="white-header">
                   <h5>LP 992 SAKURA</h5>
                </div>
                <div class="row">
                	<div class="col-sm-6 col-xs-6 goleft">
                    	<p><i class="fa fa-dollar"></i> 698.000</p>
                  	</div>
                	<div class="col-sm-6 col-xs-6"></div>
                </div>
                <div class="centered">
                  	<img src="<?php echo base_url(); ?>assets/img/H0001.JPG" width="120">
                </div>
             </div>
		</div><!-- /col-md-4 -->
						
						
		<div class="col-md-4 mb">
    	    <div class="white-panel pn">
        	    <div class="white-header">
            	   <h5>LEMARI MAKAN 2</h5>
            	</div>
            	<div class="row">
              		<div class="col-sm-6 col-xs-6 goleft">
                		<p><i class="fa fa-dollar"></i> 752.500</p>
              		</div>
              		<div class="col-sm-6 col-xs-6"></div>
            	</div>
            	<div class="centered">
              		<img src="<?php echo base_url(); ?>assets/img/H0002.JPG" width="120">
            	</div>
          </div>
      	</div><!-- /col-md-4 -->
						
		<div class="col-md-4 mb">
            <div class="white-panel pn">
                <div class="white-header">
                   <h5>MEJA RIAS 120</h5>
                </div>
                <div class="row">
                  <div class="col-sm-6 col-xs-6 goleft">
                    <p><i class="fa fa-dollar"></i> 757.500</p>
                  </div>
                  <div class="col-sm-6 col-xs-6"></div>
                </div>
                <div class="centered">
                  <img src="<?php echo base_url(); ?>assets/img/H0004.JPG" width="120">
                </div>
              </div>
          </div><!-- /col-md-4 -->

          <div class="col-md-4 mb">
            <div class="white-panel pn">
                <div class="white-header">
                   <h5>KITCHEN SET ATAS 3</h5>
                </div>
                <div class="row">
                  <div class="col-sm-6 col-xs-6 goleft">
                    <p><i class="fa fa-dollar"></i> 950.500</p>
                  </div>
                  <div class="col-sm-6 col-xs-6"></div>
                </div>
                <div class="centered">
                  <img src="<?php echo base_url(); ?>assets/img/H0005.JPG" width="200">
                </div>
              </div>
          </div><!-- /col-md-4 -->
			</div><!-- /row -->
  </div>